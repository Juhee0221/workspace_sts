package com.example.vmSystem.service;

public class SaleServiceImpl {
}
