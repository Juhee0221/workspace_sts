package com.example.vmSystem.service;

public interface SaleService {

}
